package com.jpmc.dt.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class ReportGeneratorTest   extends TestCase
{
   
    public ReportGeneratorTest(String test)
    {
        super(test);
    }


    public static Test suite()
    {
        return new TestSuite(ReportGeneratorTest.class );
    }

   
    public void testApp()
    {
        assertTrue( true );
    }
}