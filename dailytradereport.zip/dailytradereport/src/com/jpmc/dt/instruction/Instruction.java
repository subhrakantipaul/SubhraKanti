package com.jpmc.dt.instruction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

/**
 * Describes an instruction sent by various clients in order to buy or sell
 */
public class Instruction {

    // A financial entity Entity .should be Unique for each 
    private final String entity;

    // represents Buy or Sell
    private final TradeAction tradeTction;

    // date of instruction
    private final LocalDate instructionDate;

    // date of settlement
    private LocalDate settlementDate;

    private final InstructionDetails details;

    public Instruction(
            String entity,
            TradeAction action,
            Currency currency,
            LocalDate instructionDate,
            LocalDate settlementDate,
            BigDecimal agreedFx,
            Integer units,
            BigDecimal pricePerUnit)
    {
        this(
            entity, action,instructionDate, settlementDate,
            new InstructionDetails(currency, agreedFx, units, pricePerUnit));
    }

    
    
    
        public Instruction(String entity, TradeAction tradeTction,
			LocalDate instructionDate, LocalDate settlementDate,
			InstructionDetails details) {
		super();
		this.entity = entity;
		this.tradeTction = tradeTction;
		this.instructionDate = instructionDate;
		this.settlementDate = settlementDate;
		this.details = details;
	}

	public String getEntity() {
        return entity;
    }

    public TradeAction getAction() {
        return tradeTction;
    }

    public LocalDate getInstructionDate() {
        return instructionDate;
    }

    public void setSettlementDate(LocalDate newDate) {
        settlementDate = newDate;
    }

    public LocalDate getSettlementDate() {
        return settlementDate;
    }

    public InstructionDetails getDetails() {
        return details;
    }

    public Currency getCurrency() {
        return getDetails().getCurrency();
    }

    public BigDecimal getAgreedFx() {
        return getDetails().getAgreedFx();
    }

    public Integer getUnits() {
        return getDetails().getUnits();
    }

    public BigDecimal getPricePerUnit() {
        return getDetails().getPricePerUnit();
    }

    public BigDecimal getTradeAmount() {
        return getDetails().getTradeAmount();
    }

    
    
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((entity == null) ? 0 : entity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Instruction other = (Instruction) obj;
		if (entity == null) {
			if (other.entity != null)
				return false;
		} else if (!entity.equals(other.entity))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Instruction [entity=" + entity + "]";
	}

   
}
