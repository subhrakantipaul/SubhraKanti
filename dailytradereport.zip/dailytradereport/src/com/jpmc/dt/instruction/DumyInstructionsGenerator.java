package com.jpmc.dt.instruction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

//Generates Dummy Data 
public class DumyInstructionsGenerator {
	
	//Generating  Set of dummy instructions Data (by passing  value through constructor)
    public static Set<Instruction> getDumyInstructions() {
        return new HashSet<>(Arrays.asList(

			 new Instruction(
                "FOO",
                TradeAction.BUY,
                Currency.getInstance("AUD"),
                LocalDate.of(2016, 1, 1),
                LocalDate.of(2017, 1, 2),
                BigDecimal.valueOf(0.50),
                200,
                BigDecimal.valueOf(100.25)),
	
			 new Instruction(
		                "BAR",
		                TradeAction.SELL,
		                Currency.getInstance("SGD"),
		                LocalDate.of(2015, 3, 5),
		                LocalDate.of(2017, 2, 7),
		                BigDecimal.valueOf(0.75),
		                200,
		                BigDecimal.valueOf(127.58)),
			 
	         new Instruction(
                "SUAD BANK",
                TradeAction.SELL,
                Currency.getInstance("AED"),
                LocalDate.of(2016, 1, 5),
                LocalDate.of(2016, 1, 7),
                BigDecimal.valueOf(0.22),
                450,
                BigDecimal.valueOf(150.5)),
			
        		
        	new Instruction(
                "JPMC",
                TradeAction.BUY,
                Currency.getInstance("USD"),
                LocalDate.of(2016, 3, 10),
                LocalDate.of(2016, 3, 20),
                BigDecimal.valueOf(0.50),
                200,
                BigDecimal.valueOf(100.25)),

            new Instruction(
                "Morgan Stanley",
                TradeAction.SELL,
                Currency.getInstance("USD"),
                LocalDate.of(2016, 3, 10),
                LocalDate.of(2016, 3, 21),
                BigDecimal.valueOf(0.34),
                100,
                BigDecimal.valueOf(400.6)),

            new Instruction(
                "Bank of America",
                TradeAction.BUY,
                Currency.getInstance("USD"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                20,
                BigDecimal.valueOf(40.6)),

            new Instruction(
                "ANZ",
                TradeAction.SELL,
                Currency.getInstance("AUD"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                1000,
                BigDecimal.valueOf(160.55)),

            new Instruction(
                "Royal Bank of Scotland",
                TradeAction.SELL,
                Currency.getInstance("EUR"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                120,
                BigDecimal.valueOf(340.35)),
            new Instruction(
                "Barclays PLC",
                TradeAction.BUY,
                Currency.getInstance("EUR"),
                LocalDate.of(2019, 4, 10),
                LocalDate.of(2019, 3, 21),
                BigDecimal.valueOf(0.34),
                120,
                BigDecimal.valueOf(250.75)),
            new Instruction(
                "DBS",
                TradeAction.SELL,
                Currency.getInstance("SGD"),
                LocalDate.of(2018, 5, 12),
                LocalDate.of(2019, 3, 21),
                BigDecimal.valueOf(0.34),
                120,
                BigDecimal.valueOf(450.75))
        ));
    }
}
