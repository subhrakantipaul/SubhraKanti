package com.jpmc.dt.instruction;

// Enum determining Buy or Sell Constant
public enum TradeAction {
    BUY("B"),
    SELL("S");

    private String text;
    
    TradeAction(String text) {
        this.setText(text);
    }
    
    public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
