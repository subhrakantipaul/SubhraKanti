package com.jpmc.dt.report;

import com.jpmc.dt.instruction.Instruction;
import com.jpmc.dt.workingday.ArabiaWorkingDays;
import com.jpmc.dt.workingday.DefaultWorkingDays;
import com.jpmc.dt.workingday.WorkingDays;
import java.time.LocalDate;
import java.util.Currency;
import java.util.Set;

//Instruction Settlement date calculator
public class InstructionSettlementDateCalculator {

    
    //calculate settlement date for every given instruction
    public static void calculateSettlementDates(Set<Instruction> instructions) {
        instructions.forEach(InstructionSettlementDateCalculator::calculateSettlementDate);
    }

    
    // Calculate the settlementDate Based on Country Currency
    public static void calculateSettlementDate(Instruction instruction) {

        final WorkingDays workingDaysMechanism = getWorkingDaysStrategy(instruction.getCurrency());

        final LocalDate newSettlementDate =
                workingDaysMechanism.findFirstWorkingDate(instruction.getSettlementDate());

        if (newSettlementDate != null) {
            instruction.setSettlementDate(newSettlementDate);
        }
    }

    //Find working Day as per currency
    //If currency code is AED or SAR , then Arabia working date or default
    private static WorkingDays getWorkingDaysStrategy(Currency currency) {
        if ((currency.getCurrencyCode().equalsIgnoreCase("AED")) ||
            (currency.getCurrencyCode().equalsIgnoreCase("SAR")))
        {
            return ArabiaWorkingDays.getInstance();
        }
        return DefaultWorkingDays.getInstance();
    }
}
