package com.jpmc.dt.main;

import com.jpmc.dt.instruction.DumyInstructionsGenerator;
import com.jpmc.dt.instruction.Instruction;
import com.jpmc.dt.report.ReportGenerator;

import java.util.Set;


//Starting point of Execution 
public class Main {

    public static void main(String[] args) {
        final Set<Instruction> instructions = DumyInstructionsGenerator.getDumyInstructions();
        ReportGenerator reportGenerator = new ReportGenerator();

        System.out.println(reportGenerator.generateInstructionsReport(instructions));
    }
}
